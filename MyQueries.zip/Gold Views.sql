CREATE OR ALTER VIEW vw_sales_summary
AS
SELECT
    YEAR(order_date) AS sales_year,
    MONTH(order_date) AS sales_month,
    SUM(total_sales) AS sales,
    SUM(total_profit) AS profit
FROM fact_orders
GROUP BY
    YEAR(order_date),
    MONTH(order_date);

select * from fact_orders;


SELECT TOP 20 *
FROM dim_geography;

SELECT COUNT(*) FROM dim_geography;