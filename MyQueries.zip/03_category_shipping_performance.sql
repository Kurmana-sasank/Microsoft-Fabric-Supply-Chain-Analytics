SELECT
    p.category_name,

    COUNT(*) AS total_orders,

    AVG(f.delivery_delay_days) AS avg_delay_days,

    SUM(
        CASE
            WHEN f.is_late_delivery = 1
            THEN 1
            ELSE 0
        END
    ) AS late_orders

FROM fact_delivery_performance f

INNER JOIN fact_order_items oi
    ON f.order_item_id = oi.order_item_id

INNER JOIN dim_product p
    ON oi.product_card_id = p.product_card_id

GROUP BY p.category_name

ORDER BY avg_delay_days DESC;