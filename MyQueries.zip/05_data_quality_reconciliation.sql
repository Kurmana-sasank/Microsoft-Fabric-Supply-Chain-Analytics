SELECT
    'bronze_supply_chain_raw' AS table_name,
    COUNT(*) AS row_count
FROM bronze_supply_chain_raw

UNION ALL

SELECT
    'silver_supply_chain',
    COUNT(*)
FROM silver_supply_chain

UNION ALL

SELECT
    'fact_order_items',
    COUNT(*)
FROM fact_order_items;