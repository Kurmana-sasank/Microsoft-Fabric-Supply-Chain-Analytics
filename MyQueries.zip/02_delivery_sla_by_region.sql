SELECT
    order_region,

    COUNT(*) AS total_shipments,

    SUM(
        CASE
            WHEN is_late_delivery = 1
            THEN 1
            ELSE 0
        END
    ) AS late_shipments,

    ROUND(
        SUM(
            CASE
                WHEN is_late_delivery = 1
                THEN 1
                ELSE 0
            END
        ) * 100.0 / COUNT(*),
        2
    ) AS late_delivery_rate

FROM fact_delivery_performance

GROUP BY order_region

ORDER BY late_delivery_rate DESC;