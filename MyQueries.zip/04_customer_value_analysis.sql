SELECT
    customer_id,
    customer_lifetime_value,

    DENSE_RANK() OVER
    (
        ORDER BY customer_lifetime_value DESC
    ) AS customer_rank

FROM fact_customer_behavior

ORDER BY customer_rank;