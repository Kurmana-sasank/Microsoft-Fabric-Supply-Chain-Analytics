WITH monthly_sales AS
(
    SELECT
        YEAR(order_date) AS sales_year,
        MONTH(order_date) AS sales_month,
        SUM(total_sales) AS monthly_sales
    FROM fact_orders
    GROUP BY
        YEAR(order_date),
        MONTH(order_date)
)

SELECT
    sales_year,
    sales_month,
    monthly_sales,

    LAG(monthly_sales) OVER
    (
        ORDER BY sales_year, sales_month
    ) AS previous_month_sales,

    ROUND(
        (
            monthly_sales -
            LAG(monthly_sales) OVER
            (
                ORDER BY sales_year, sales_month
            )
        ) * 100.0
        /
        NULLIF(
            LAG(monthly_sales) OVER
            (
                ORDER BY sales_year, sales_month
            ),
            0
        ),
        2
    ) AS growth_pct

FROM monthly_sales
ORDER BY sales_year, sales_month;